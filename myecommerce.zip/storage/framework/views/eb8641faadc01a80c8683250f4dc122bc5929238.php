
<?php $__env->startSection('title'); ?>
Edit Slider
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>
<div class="main-panel">
        <div class="content-wrapper">
        <div class="row grid-margin">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Slier Slider</h4>
                  <?php if(count($errors) >0): ?>
                  <div class="alert alert-danger">
                     <ul>
                       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                       <li><?php echo e($error); ?></li>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                     </div>
                  <?php endif; ?> 
                  <?php if(Session::has('status')): ?>
                  <div class="alert alert-success">
                    <?php echo e(Session::get('status')); ?>

</div>
                 <?php endif; ?>
                  <form class="cmxform" id="commentForm" method="post" action="<?php echo e(url('/modifierslider')); ?>" enctype="multipart/form-data">
        
                      <?php echo e(csrf_field()); ?>

                    <fieldset>
                      <div class="form-group">
                        <label for="cname">Description one</label>
                        <input id="cname" class="form-control" name="id" value="<?php echo e($slider->id); ?>" minlength="2" type="hidden" >

                        <input id="cname" class="form-control" name="description1" value="<?php echo e($slider->description1); ?>"  type="text" >
                      </div>
                      <div class="form-group">
                        <label for="cname">Description two</label>
                        <input id="cname" class="form-control" name="description2"  value="<?php echo e($slider->description2); ?>"  type="text" >
                      </div>
             
                      <div class="form-group">
                        <label for="cname">Image</label>
                        <input id="cname" class="form-control" name="slider_image"  type="file" >
                      </div>

       
                      <input class="btn btn-primary" type="submit" value="Modifier">
                    </fieldset>
                  </form>
                </div>
              </div>
            </div>
          </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <!-- <script src="backend/js/form-validation.js"></script>
  <script src="backend/js/bt-maxLength.js"></script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oumark\Desktop\laravel\myecommerce\resources\views/admin/editslider.blade.php ENDPATH**/ ?>