
<?php $__env->startSection('title'); ?>
  Edit  Produit
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenu'); ?>
<div class="main-panel">
        <div class="content-wrapper">
        <div class="row grid-margin">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Edit produit</h4>
                  <?php if(count($errors) >0): ?>
                  <div class="alert alert-danger">
                     <ul>
                       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                       <li><?php echo e($error); ?></li>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                     </div>
                  <?php endif; ?> 
                  <?php if(Session::has('status')): ?>
                  <div class="alert alert-success">
                    <?php echo e(Session::get('status')); ?>

</div>
                 <?php endif; ?>
                  <form class="cmxform" id="commentForm" method="post" action="<?php echo e(url('/modifierproduit')); ?>" enctype="multipart/form-data">
        
                      <?php echo e(csrf_field()); ?>

                    <fieldset>
                      <div class="form-group">
                        <label for="cname">Nom Produit</label>
                        <input id="cname" class="form-control" name="id" value="<?php echo e($product->id); ?>" minlength="2" type="hidden" >

                        <input id="cname" class="form-control" value="<?php echo e($product->product_name); ?>"  name="product_name" minlength="2" type="text" >
                      </div>
                      <div class="form-group">
                        <label for="cname">Prix du Produit</label>
                        <input id="cname" class="form-control" name="product_price" value="<?php echo e($product->product_price); ?>"  type="number" >
                      </div>
                      <div class="form-group">
                        <?php echo e(Form::label('','Categorie du produit')); ?>

                        <?php echo e(Form::select('product_category',$categories,$product->product_category,['class'=>'form-control'])); ?>

                        
                      </div>
                      <div class="form-group">
                        <label for="cname">Image</label>
                        <input id="cname" class="form-control" name="product_image"  type="file" >
                      </div>

                      
                      <!-- <div class="form-group">
                        <label for="cemail">E-Mail (required)</label>
                        <input id="cemail" class="form-control" type="email" name="email" required>
                      </div>
                      <div class="form-group">
                        <label for="curl">URL (optional)</label>
                        <input id="curl" class="form-control" type="url" name="url">
                      </div>
                      <div class="form-group">
                        <label for="ccomment">Your comment (required)</label>
                        <textarea id="ccomment" class="form-control" name="comment" required></textarea>
                      </div> -->
                      <input class="btn btn-primary" type="submit" value="Modifier">
                    </fieldset>
                  </form>
                </div>
              </div>
            </div>
          </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <!-- <script src="backend/js/form-validation.js"></script>
  <script src="backend/js/bt-maxLength.js"></script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oumark\Desktop\laravel\myecommerce\resources\views/admin/editproduit.blade.php ENDPATH**/ ?>